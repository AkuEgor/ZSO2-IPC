#include <message_queue.h>


int createMsgQ(int messageKey, messageQID *objMessageQID) {
	objMessageQID->msgID = msgget((key_t)messageKey, IPC_CREAT | 0777);
	if(objMessageQID->msgID == FAILURE) {
		perror("Failed to create message Queue");
		return FAILURE;
	}
	return SUCCESS;
}


int sendMsg(messageQID *objMessageQID, messageBuf *objMessageBuf) {
	int response;

	response = msgsnd(objMessageQID->msgID, (void *)objMessageBuf, sizeof(objMessageBuf->msg), IPC_NOWAIT);
	if(response == FAILURE) {
		fprintf(stderr, "Failed to send message errno = %d\n", errno);
		return errno;
	}
	return SUCCESS;
}

int recvMsg(messageQID *objMessageQID, messageBuf *objMessageBuf) {
	int response;
	response = msgrcv(objMessageQID->msgID, (void *)objMessageBuf, sizeof(objMessageBuf->msg), TEST_MSG_TYPE, MSG_NOERROR | IPC_NOWAIT);
	if(response == FAILURE) {
        if(errno != ENOMSG) {
		    fprintf(stderr, "Failed to recv message errno = %s\n", strerror(errno));
        }
		return FAILURE;
	}
	return SUCCESS;
}

int recvMsgBlocking(messageQID *objMessageQID, messageBuf *objMessageBuf) {
	int response;
	response = msgrcv(objMessageQID->msgID, (void *)objMessageBuf, sizeof(objMessageBuf->msg), STATS_MSG_TYPE, MSG_NOERROR);
	if(response == FAILURE) {
		fprintf(stderr, "Blocking Recv: Failed to recv message errno = %s\n", strerror(errno));
		return FAILURE;
	}
	return SUCCESS;
}

int rmMsgQ(messageQID *objMessageQID) {
    int retVal;
    struct msqid_ds dsBuf;
    retVal = msgctl(objMessageQID->msgID, IPC_RMID, &dsBuf);
    if(retVal != 0) {
        perror("Failed to remmove message Queue");
    } else {
        fprintf(stdout, "Successfully removed Queue %d\n", objMessageQID->msgID);
    }
}
