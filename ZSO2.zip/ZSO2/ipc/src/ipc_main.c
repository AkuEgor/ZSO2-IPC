#include <ipc_node.h>

int main() {
    startParentNode();
    return 0;
}


/**            Flow
1. Open Keyboard Reading Process.
2. Create 3 messaging process as child process of keyboard reading process.
3. Now the keyboard reading process knows the pids of children i.e. the message reading process.
4. Messaging child processes can send messages to each other over message queue
5. Keyboard reading process may send signals to messaging process on receiving PID from keyboard,
 so that, they can send the logs via message queue.
*/