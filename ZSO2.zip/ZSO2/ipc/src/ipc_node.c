/**
   Node creation and communication handling
*/
#include <ipc_node.h>

void recvInfoFromChild(pid_t pid) {
    int retVal;
    messageBuf objStatsMsg;
    printf("\033[0;35m");
    fprintf(stdout, "Going to signal child %d...\n", pid);
    retVal = kill(pid, SIGINT);
    if(retVal == -1) {
        fprintf(stderr, "Error signalling child %d. errno:%d \n", (int)pid, errno);
    }
    createMsgQ(PARENT_MSG_KEY, &parentMQID);
    objStatsMsg.mtype = STATS_MSG_TYPE;
    recvMsgBlocking(&parentMQID, &objStatsMsg);
    printf("\033[0;3m");
    fprintf(stdout, "Received Info: %d\n", objStatsMsg.msg);
    printf("\033[0m");
}

void startParentNode() {
    isAnyChildAlive = FALSE;
    int customPID;
    struct sigaction action;
    
    fprintf(stdout, "Starting Parent Nodes...\n");
    createChildNodes();
    action.sa_handler = mainSignalHandler;
    action.sa_flags = 0;
    sigaction(SIGINT, &action, NULL);
    while(isAnyChildAlive==TRUE) {
        printf("\033[0;31m");
        fprintf(stdout, "Enter PID to get info from child\n");
        fprintf(stdout, "Available PIDs:\n");
        printAvilablePIDs();
        printf("\033[0m");
        scanf("%d", &customPID);
        recvInfoFromChild((pid_t)customPID);
    }
}

int createChildNodes() {
    pid_t pid;
    int i;
    fprintf(stdout, "Starting Child Nodes...\n");
    for (i=0; i < MAX_CHILDS; ++i) {
        receivedMessagesArray[i] = 0;
        pid = fork();
        if(pid == 0) {
            childArray[i] = getpid();
            runChildNode(i);
            break;
        } else {
            isAnyChildAlive = TRUE;
            childArray[i] = pid;
        }
    }
    return 0;
}

int runChildNode(int index) {
    pid_t childPID;
    int i;
    childPID = getpid();
    int aliveNeighbourCount = MAX_CHILDS-1;
    int hasRcvdMsg = 0;
    int receivedMessageCount = 0;
    struct sigaction action;
    messageQID neighbourMQID[2];
    messageQID currentMQID;
    messageBuf objMessageBuf;
    int sendError;
    int maskedNeighbour =-1;


    fprintf(stdout, "[%d]Starting Child Node\n", (int)childPID);
    action.sa_handler = signalHandler;
    action.sa_flags = 0;
    sigaction(SIGINT, &action, NULL);

    for(i=0;i<MAX_CHILDS;++i) {
        if(i == index) {
           createMsgQ(NODE_MSG_KEY+i, &currentMQID); 
        }
        createMsgQ(NODE_MSG_KEY+i, &neighbourMQID[i]);
    }

    while (receivedMessageCount < 3) {
        //Send message to random neighbour
        i = rand() % 2;   
        objMessageBuf.mtype = TEST_MSG_TYPE;
        objMessageBuf.msg = childPID;
        if(i != maskedNeighbour) {
            sendError = sendMsg(&neighbourMQID[i], &objMessageBuf);
            //If we get invalid error on sending message, the message queue is no more
            if(sendError == 22) {
                maskedNeighbour = i;
                aliveNeighbourCount--;
            }
        }
        if(aliveNeighbourCount == 0) {
            break;
        }
        sleep(SEND_SLEEP_TIME);
        hasRcvdMsg = recvMsg(&currentMQID, &objMessageBuf);
        if(hasRcvdMsg == SUCCESS) {
            receivedMessageCount++;
            receivedMessagesArray[index] = receivedMessageCount;
            printf("\033[0;36m"); 
            fprintf(stdout, "[%d]receivedMessageCount = %d.\n", (int)childPID, receivedMessageCount);
            printf("\033[0m"); 
        }
        sleep(RECV_SLEEP_TIME);

    }

    rmMsgQ(&currentMQID);

    exit(0);
    return 0;
}

void printAvilablePIDs() {
    int i;
    for(i=0 ; i < MAX_CHILDS; ++i) {
        printf("%d\n", (int)childArray[i]);
    }
}

void signalHandler(int signal_number)  {
    int i;
    messageBuf objStatsMsg;
    pid_t currentPID = getpid();
    printf("\033[0;32m");
    fprintf(stdout, "[%d]Received Signal...\n", (int)currentPID);
    printf("\033[0m");
    boolean found = FALSE;
    for(i=0 ; i < MAX_CHILDS ; ++i) {
        if(currentPID == childArray[i]) {
            objStatsMsg.mtype = STATS_MSG_TYPE;
            objStatsMsg.msg = receivedMessagesArray[i];
            found =TRUE;
            break;
        }
    }
    if(found == FALSE) {
        fprintf(stderr, "Signal is in any child process\n");
        return;
    }
    createMsgQ(PARENT_MSG_KEY, &parentMQID);
    sendMsg(&parentMQID, &objStatsMsg);
}

void mainSignalHandler(int signal_number)  {
    rmMsgQ(&parentMQID);
    exit(0);
}