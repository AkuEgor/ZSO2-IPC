#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <message_queue.h>

#define MAX_CHILDS 3
#define NODE_MSG_KEY 100
#define PARENT_MSG_KEY 200
//Adjust the below values to vary time delay in seconds
#define SEND_SLEEP_TIME 3
#define RECV_SLEEP_TIME 3

typedef enum {
    FALSE,
    TRUE
} boolean;

void startParentNode();
int createChildNodes();
int runChildNode();
void printAvilablePIDs();
void signalHandler(int signal_number);
void mainSignalHandler(int signal_number);

boolean isAnyChildAlive;
pid_t childArray[MAX_CHILDS];
pid_t receivedMessagesArray[MAX_CHILDS];
messageQID parentMQID;