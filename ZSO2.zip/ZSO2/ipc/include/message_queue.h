#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#define MSG_SIZE 256
#define FAILURE -1
#define SUCCESS 0
#define TEST_MSG_TYPE 10
#define STATS_MSG_TYPE 20

typedef struct MessageQID {
	int msgID;
}messageQID;

typedef struct MessageBuf {
	long mtype;
	int msg;
}messageBuf;

int createMsgQ(int messageKey, messageQID *objMessageQID);
int sendMsg(messageQID *objMessageQID, messageBuf *objMessageBuf);
int recvMsg(messageQID *objMessageQID, messageBuf *objMessageBuf);
int rmMsgQ(messageQID *objMessageQID);
int recvMsgBlocking(messageQID *objMessageQID, messageBuf *objMessageBuf);